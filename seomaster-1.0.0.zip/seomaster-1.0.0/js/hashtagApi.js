const APIURL = "https://api.github.com/users/";
const search = document.getElementById("search-3");
const form = document.getElementById("form-3");
const Social_Search = "https://api.social-searcher.com/v2/users?";
const APISocial = "77a1f07d09aec6a9f61a2213d862c873";
const APIKey = "d5a3b24b86msh040f5a74f539948p18082bjsnaac02aa9047b";

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const user = search.value;
  getHashtag(facebookHead, user, APISocial, "twitter");
});

// ******* Instagram ********

const facebookHead = {
  method: "GET",
};
async function getHashtag(options, user, APISocial, network) {
  const URL1 = `https://api.social-searcher.com/v2/search?q=${user}&key=${APISocial}&network=${network}`;
  console.log(URL1);
  fetch(URL1, options)
    .then((response) => response.json())
    .then((response) => {
      createUserFaceBook(response.posts, network);
    })
    .catch((err) => console.error(err));
}

let container = document.querySelector(".main-3");

function createUserFaceBook(response, network) {
  if (network == "twitter") {
    var facebook_img = `asstes/social-logo/iconmonstr-twitter-4.svg`;
  } else {
    var facebook_img = `asstes/social-logo/iconmonstr-linkedin-5.svg`;
  }
  for (let i = 0; i < response.length; i++) {
    let div = document.createElement("div");
    div.classList.add("d-flex", "justify-content-center", "mt-5");
    div.innerHTML = `
                                        <div class="col-lg-8 col-md-6 wow zoomIn justify-content-center"
                        style="visibility: visible; animation-name: zoomIn;">
                        <div class="" data-wow-delay="0.3s id=" 1"="">
                       
                            <div class="service-item d-flex flex-column justify-content-center text-center rounded">
                            <img class="twitter-logo" src="https://www.freepnglogos.com/uploads/twitter-logo-png/twitter-logo-in-blue-circle-design-twitter-icon-15.png" width="200" alt="twitter logo in blue circle design, twitter icon" />
                                <div class="text-bio">
                                    
                                    <p>${response[i].text}
                                    </p>
                                    
                                </div>
                                <div class="d-flex align-items-center">
                                    <img class="img-fluid flex-shrink-0 rounded-circle" src=${response[i].user.image}
                                        style="width: 50px; height: 50px;">
                                    <div class="user text-left">
                                        <h6 class=" mb-1">${response[i].user.name}</h6>
                                        <a class="url" href=${response[i].user.url}>${response[i].user.url}</a>
                                    </div>
                                    <div class="">
                                        <img src="asstes/social-logo/heart-svgrepo-com.svg" class="m-2" width="6%"
                                            alt="">
                                        <span>${response[i].popularity[1].count}</span>
                                    </div>
                                    <div class="">
                                        <img src="asstes/social-logo/retweet-svgrepo-com.svg" class="m-2" width="6%"
                                            alt="">
                                        <span>${response[i].popularity[0].count}</span>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>`;
    container.appendChild(div);
  }
}
